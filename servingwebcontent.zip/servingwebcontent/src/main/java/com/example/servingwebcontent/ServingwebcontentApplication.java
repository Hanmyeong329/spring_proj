package com.example.servingwebcontent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServingwebcontentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServingwebcontentApplication.class, args);
	}

}
